package BusinessLogic;

import DataAccess.ProductDAO;
import DataModel.Product;

import java.util.List;
/**
 * ProductBLL class handles the calling for the functions in ProductDAO and validates the fields for
 * creating or updating the product fields(non-null name, price and quantity grater than 0).
 * */

public class ProductBLL {

    private ProductDAO productDAO= new ProductDAO();

    /**
     * Function for adding product-from ProductDAO + validating the fields: non-empty name, price and quantity grater than 0
     * */
    public void addProduct(Product product)
    {
        validateProduct(product);
        productDAO.insert(product);
    }

    /**
     * Calls function from ProductDAO to view the table with products
     * */
    public List<Product> viewAllProducts()
    {
        return productDAO.findAll();
    }

    /**
     * Calls function from ProductDAO to find product by id
     * */
    public Product findProductById(int id)
    {
        return productDAO.findById(id);
    }

    /**
     * Calls function from ProductDAO to update product + validate fields
     * */
    public void updateProduct(Product product)
    {
        validateProduct(product);
        productDAO.update(product);
    }

    /**
     * Calls function from ProductDAO to delete product from table
     * */
    public void deleteProduct(int id)
    {
         productDAO.delete(id);
    }

    /**
     * Function to validate product's name(non-null) and price, quantity MUST BE grater than 0
     * */
    public void validateProduct(Product product) {
        if (product.getName() == null || product.getName().isEmpty())
        {
            throw new IllegalArgumentException("Product name cannot be empty.");
        }

        if(product.getPrice()<0)
        {
            throw new IllegalArgumentException("Price cannot be negative.");
        }

        if(product.getQuantity()<0)
        {
            throw new IllegalArgumentException("Quantity cannot be negative.");
        }
    }

}
