package BusinessLogic;

import DataAccess.ClientDAO;
import DataModel.Client;

import java.util.List;
/**ClientBLL class handles the calling for the functions in ClientDAO and validates the fields for
 * creating or updating the client fields(non-null valid email with @ and non-null name).*/
public class ClientBLL
{
    private ClientDAO clientDAO= new ClientDAO();

    /**
     * Function for addinga client-from ClientDAO + validating the fields: non-null valid email with @ and non-null name
     * */
    public void addClient(Client client)
    {
        validateClient(client);
        clientDAO.insert(client);
    }

    /**
     * Calls function from ClientDAO to view the table with clients
     * */
    public List<Client> viewAllClients()
    {
        return clientDAO.findAll();
    }

    /**
     * Calls function from ClientDAO to find client by id
     * */
    public Client findClientById(int id)
    {
        return clientDAO.findById(id);
    }

    /**
     * Calls function from ClientDAO to update client + validate fields
     * */
    public void updateClient(Client client)
    {
        validateClient(client);
        clientDAO.update(client);
    }

    /**
     * Calls function from ClientDAO to delete client from table
     * */
    public void deleteClient(int id)
    {
        clientDAO.delete(id);
    }

    /**
     * Function to validate client's name(non-null) and email(non-null, must contain @)
     * */
    public void validateClient(Client client)
    {
        if(client.getName()==null || client.getName().isEmpty())
        {
            throw new IllegalArgumentException("Client name cannot be empty.");
        }

        if(client.getEmail()==null || !client.getEmail().contains("@"))
        {
            throw new IllegalArgumentException("Invalid client email.");
        }
    }
}
