package BusinessLogic;

import DataAccess.BillDAO;
import DataAccess.ClientDAO;
import DataAccess.OrderDAO;
import DataAccess.ProductDAO;
import DataModel.Bill;
import DataModel.Client;
import DataModel.Order;
import DataModel.Product;

import java.util.List;
import java.util.Map;

/**
 * OrderBLL class handles the calling for the functions in OrderDAO and validates the fields for
 * placing order fields for products (we must have at least a product to place an order for and the quantity must be
 * grater than 0).
 * */

public class OrderBLL {

    private OrderDAO orderDAO= new OrderDAO();
    private ProductDAO productDAO= new ProductDAO();
    private BillDAO billDAO=new BillDAO();
    private ClientDAO clientDAO= new ClientDAO();

    /**
     * Function for creating an order
     * */
    public void placeOrder(Order order) {
        validateOrder(order);
        Client client = clientDAO.findById(order.getClientId());

        order.getProducts().entrySet().stream()
                .forEach(entry->{
                    Product product=productDAO.findById(entry.getKey().getId());
                    int orderedQuantity=entry.getValue();
                    if(product.getQuantity()<orderedQuantity)
                    {
                        throw new IllegalArgumentException("Under stock product"+product.getName());
                    }

                    product.setQuantity(product.getQuantity()-orderedQuantity);
                    productDAO.update(product);
                });

        // orderDAO.insert(order);
        int orderId = orderDAO.insert(order);

        order.getProducts().entrySet().stream().forEach(entry->{
            Product product=productDAO.findById(entry.getKey().getId());
            int quantity=entry.getValue();

            Bill bill= new Bill(0, orderId, client.getName(), product.getName(), quantity, product.getPrice(), quantity* product.getPrice());

            billDAO.insert(bill);
        });



    }

    /**
     * Function for viewing all order details
     * */
    public List<Order> viewAllOrders()
    {
        return orderDAO.findAll();
    }

    /**
     * Function to validate order data- to include at least an object*/
    private void validateOrder(Order order)
    {
        if(order.getProducts()==null || order.getProducts().isEmpty())
        {
            throw new IllegalArgumentException("Order must contain at least one product.");
        }
    }

}
