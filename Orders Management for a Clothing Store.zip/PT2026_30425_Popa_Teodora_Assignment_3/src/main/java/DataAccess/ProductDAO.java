package DataAccess;

import DataModel.Client;
import Connection.ConnectionFactory;
import DataModel.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * ProductDAO handles creating, updating, deleting and viewing products.
 * Moreover, it extends AbstractDAO.
 * The class uses JDBC connections and SQL queries to communicate with the PostgreSQL database*/

public class ProductDAO extends AbstractDAO<Product>{

    //create product
    /**
     * For creating a new product and inserting it into the database
     * */
    public void insert(Product product) {
        String query = "INSERT INTO products(name, price, quantity) VALUES (?, ?, ?)";

        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);

            statement.setString(1, product.getName());
            statement.setInt(2, product.getPrice());
            statement.setInt(3, product.getQuantity());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
    }

    //view products
    /**
     * for viewing all products from the table from the database
     * */
    @Override
    public List<Product> findAll() {
        List<Product> products = new ArrayList<>();

        String query = "SELECT * FROM products";

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.createStatement();

            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int price= resultSet.getInt("price");
                int quantity= resultSet.getInt("quantity");
                products.add(new Product(id, name, price, quantity));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return products;
    }

    /**
     * For finding a product with a specific id
     * */
    @Override
    public Product findById(int id) {
        String query = "SELECT * FROM products WHERE id=?";

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);

            statement.setInt(1, id);

            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String name = resultSet.getString("name");
                int price= resultSet.getInt("price");
                int quantity=resultSet.getInt("quantity");

                return new Product(id, name, price, quantity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * For updating a product's data from the table
     * */
    @Override
    public void update(Product product) {
        String query = "UPDATE products SET name= ?, price= ?, quantity=? WHERE id= ?";

        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = ConnectionFactory.getConnection();
            statement =  connection.prepareStatement(query);

            statement.setString(1, product.getName());
            statement.setInt(2, product.getPrice());
            statement.setInt(3, product.getQuantity());
            statement.setInt(4, product.getId());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
    }

    /**
     * For deleting a product from the table from the database
     * */
    @Override
    public void delete(int id)
    {
        String query="DELETE FROM products WHERE id= ?";

        Connection connection=null;
        PreparedStatement statement=null;

        try{
            connection= ConnectionFactory.getConnection();
            statement=connection.prepareStatement(query);

            statement.setInt(1,id);

            statement.executeUpdate();
        }catch(SQLException e)
        {
            e.printStackTrace();
        }finally{
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
    }


}
