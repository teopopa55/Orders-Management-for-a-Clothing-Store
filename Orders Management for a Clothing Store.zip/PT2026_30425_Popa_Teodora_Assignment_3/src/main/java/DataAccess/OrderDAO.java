package DataAccess;

import DataModel.Order;
import Connection.ConnectionFactory;
import DataModel.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

/**
 * OrderDAO handles creating and viewing the orders.
 * Moreover, it extends AbstractDAO.
 * The class uses JDBC connections and SQL queries to communicate with the PostgreSQL database
 * */

public class OrderDAO extends AbstractDAO<Order>{

    //place order
    /**
     * For creating a new order and inserting it into the database
     * */
    public int insert(Order order){

        String orderQuery="INSERT INTO orders(client_id) VALUES (?)";
        String detailsQuery= "INSERT INTO order_details(order_id, product_id, price, quantity) VALUES(?, ?, ?, ?)";

        Connection connection=null;
        PreparedStatement orderStatement=null;
        PreparedStatement detailsStatement=null;
        ResultSet generatedKeys=null;
        int orderId=0;

        try{
            connection=ConnectionFactory.getConnection();

            //insert into orders table
            orderStatement=connection.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS);

            orderStatement.setInt(1, order.getClientId());

            orderStatement.executeUpdate();

            generatedKeys=orderStatement.getGeneratedKeys();


            if(generatedKeys.next()) {
                orderId = generatedKeys.getInt(1);
            }

            //insert products into order_details
            detailsStatement =connection.prepareStatement(detailsQuery);

            for(Map.Entry<Product, Integer> entry: order.getProducts().entrySet())
            {
                Product product= entry.getKey();
                int quantity=entry.getValue();

                detailsStatement.setInt(1, orderId);
                detailsStatement.setInt(2, product.getId());
                detailsStatement.setInt(3, product.getPrice());
                detailsStatement.setInt(4, quantity);

                detailsStatement.executeUpdate();
            }
        }catch(SQLException e)
        {
            e.printStackTrace();
        }finally {
            ConnectionFactory.close(generatedKeys);
            ConnectionFactory.close(orderStatement);
            ConnectionFactory.close(detailsStatement);
            ConnectionFactory.close(connection);

        }
      return orderId;

    }

    //view orders
    /**
     * for viewing all orders from the table from the database
     * */
    @Override
    public List<Order> findAll()
    {
        List<Order> orders= new ArrayList<>();

        String query="SELECT * FROM orders";

        Connection connection=null;
        Statement statement=null;
        ResultSet resultSet=null;

        try{
            connection=ConnectionFactory.getConnection();
            statement=connection.createStatement();
            resultSet=statement.executeQuery(query);

            while(resultSet.next())
            {
                int id=resultSet.getInt("id");
                int clientId=resultSet.getInt("client_id");

                orders.add(new Order(id, clientId));
            }
        }catch (SQLException e)
        {
            e.printStackTrace();
        }finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }

        return orders;
    }

}
