package DataAccess;

import Connection.ConnectionFactory;
import DataModel.Bill;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * The BillDAO class handles inserting and reading the immutable Bill history records from the log table database.
 * It preserves the historical details of orders even if clients/products are later deleted from their main tables.
 * The class uses JDBC connections and SQL queries to communicate with the PostgreSQL database.
 * */
public class BillDAO
{
    /**
     * for placing an order and introducing it into the log table
     * */
    public void insert(Bill bill)
    {
        String query= "INSERT INTO log(order_id, client_name, product_name, quantity, price, total) VALUES (?, ?, ?, ?, ?, ?)";

        try(Connection connection=ConnectionFactory.getConnection();
            PreparedStatement statement= connection.prepareStatement(query))
        {
            statement.setInt(1, bill.orderId());
            statement.setString(2, bill.clientName());
            statement.setString(3, bill.productName());
            statement.setInt(4, bill.quantity());
            statement.setInt(5, bill.price());
            statement.setInt(6, bill.total());

            statement.executeUpdate();
        }catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * for printing the table with the orders' detials unaltered and with accurate history
     * */
    public List<Bill> findAll()
    {
         List<Bill> bills= new ArrayList<>();
         String query="SELECT * FROM log";

         try(Connection connection=ConnectionFactory.getConnection();
             Statement statement= connection.createStatement();
             ResultSet rs= statement.executeQuery(query))
         {
             while(rs.next())
             {
                 bills.add(new Bill(
                         rs.getInt("id"),
                         rs.getInt("order_id"),
                         rs.getString("client_name"),
                         rs.getString("product_name"),
                         rs.getInt("quantity"),
                         rs.getInt("price"),
                         rs.getInt("total")
                 ));
             }
         }catch(SQLException e)
         {
             e.printStackTrace();
         }
         return bills;
    }

}
