package DataAccess;

import Connection.ConnectionFactory;

import java.beans.PropertyDescriptor;
import java.lang.reflect.*;
import java.sql.*;
import java.util.*;
import java.util.logging.*;
import java.lang.reflect.ParameterizedType;
import java.sql.Connection;
import java.util.List;
import java.util.logging.Logger;

/**
 * The AbstractDAO is a generic reflection-based data access class that automatically
 * performs database operations: findById, findAll, createObject for any type of model type
 * such as Client, Product, Order.
 * */
public class AbstractDAO<T> {

    //This creates a logger object used to display warning and error messages related to AbstractDAO
    protected static final Logger LOGGER=Logger.getLogger(AbstractDAO.class.getName());

    //generic type represents Client, Product, Order
    private final Class<T> type;

    //hides the compiler warning caused by the generic reflection cast
    /**
     * Initializes the data layer context by extracting generic type parameters
     * */
    @SuppressWarnings("unchecked")
    public AbstractDAO()
    {
        this.type=(Class<T>) ((ParameterizedType)
                               getClass().getGenericSuperclass())
                               .getActualTypeArguments()[0];


    }

    //for client=> Client+s=Clients
    private String getTableName()
    {
        return type.getSimpleName().toLowerCase()+"s";
    }

    private List<T> createObjects(ResultSet resultSet)
    {
        List<T> list= new ArrayList<>();

        try{
            while(resultSet.next())
            {
                Constructor<T> constructor=type.getDeclaredConstructor();
                constructor.setAccessible(true);
                T instance=constructor.newInstance();

                for(Field field: type.getDeclaredFields())
                {
                    field.setAccessible(true);
                    Object value= resultSet.getObject(field.getName());
                    PropertyDescriptor propertyDescriptor=new PropertyDescriptor(field.getName(), type);
                    Method method=propertyDescriptor.getWriteMethod();
                    method.invoke(instance, value);
                }
                list.add(instance);
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }

        return list;
    }

    /**
     *  Finds object from specific table
     *  */
    public T findById(int id)
    {
        String query="SELECT * FROM "+getTableName()+" WHERE id=?";
        try(Connection connection=ConnectionFactory.getConnection();
           PreparedStatement statement= connection.prepareStatement(query))
        {
            statement.setInt(1,id);
            ResultSet resultSet= statement.executeQuery();

            List<T> list=createObjects(resultSet);
            if(list.isEmpty()) return null;
                else return list.get(0);
        }
        catch(SQLException e)
        {
            LOGGER.log(Level.WARNING, type.getName()+"DAO findById error: "+e.getMessage());
        }
        return null;
    }

    /**
     * for viewing all objects from a specific table
     * */
    public List<T> findAll()
    {
        List<T> list= new ArrayList<>();
        String query="SELECT * FROM "+getTableName();

        try(Connection connection=ConnectionFactory.getConnection();
            Statement statement= connection.createStatement();
            ResultSet resultSet= statement.executeQuery(query))
        {
            list=createObjects(resultSet);
        }catch(SQLException e)
        {
            LOGGER.log(Level.WARNING, type.getName()+"DAO findAll error: "+e.getMessage());
        }
        return list;
    }

    /**
     * This will be implemented by each class that needs it
     * */
    public void update(T object)
    {

    }

    /**
     * This will be implemented by each class that needs it
     * */
    public void delete(int id)
    {

    }

}
