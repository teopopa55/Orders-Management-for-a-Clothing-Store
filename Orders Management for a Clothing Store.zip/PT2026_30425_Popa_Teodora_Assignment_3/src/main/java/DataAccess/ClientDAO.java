package DataAccess;

import Connection.ConnectionFactory;
import DataModel.Client;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * ClientDAO handles creating, updating, deleting and viewing clients.
 * Moreover, it extends AbstractDAO.
 * The class uses JDBC connections and SQL queries to communicate with the PostgreSQL database
 * */

public class ClientDAO extends AbstractDAO<Client> {

    //create client
    /**
     * For creating a new client and inserting it into the database
     * */
    public void insert(Client client) {
        String query = "INSERT INTO clients(name, email) VALUES (?, ?)";

        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);

            statement.setString(1, client.getName());
            statement.setString(2, client.getEmail());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
    }

    /**
     * for viewing all clients from the table from the database
     * */
    //view clients
    @Override
    public List<Client> findAll() {
        List<Client> clients = new ArrayList<>();

        String query = "SELECT * FROM clients";

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.createStatement();

            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");

                clients.add(new Client(id, name, email));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return clients;
    }

    /**
     * For finding a client with a specific id
     * */
    @Override
    public Client findById(int id) {
        String query = "SELECT * FROM clients WHERE id=?";

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);

            statement.setInt(1, id);

            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");

                return new Client(id, name, email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * For updating a client's data from the table
     * */
    @Override
    public void update(Client client) {
        String query = "UPDATE clients SET name= ?, email= ? WHERE id= ?";

        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = ConnectionFactory.getConnection();
            statement =  connection.prepareStatement(query);

            statement.setString(1, client.getName());
            statement.setString(2, client.getEmail());
            statement.setInt(3, client.getId());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
    }

    /**
     * For deleting a client from the table from the database
     * */
    @Override
    public void delete(int id)
    {
        String query="DELETE FROM clients WHERE id= ?";

        Connection connection=null;
        PreparedStatement statement=null;

        try{
            connection=ConnectionFactory.getConnection();
            statement=connection.prepareStatement(query);

            statement.setInt(1,id);

            statement.executeUpdate();
        }catch(SQLException e)
        {
            e.printStackTrace();
        }finally{
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
    }

}

