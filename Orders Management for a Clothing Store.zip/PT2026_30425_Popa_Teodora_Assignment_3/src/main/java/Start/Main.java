package Start;

import Presentation.Controller;
import Presentation.View;

/**
 * Main class which runs and assembles everything
 * */
public class Main
{
    /**
     * This method initializes and assembles the main components of the application and starts the GUI.
     * */
    public static void main(String[] args)
    {
        View view = new View();
        Controller controller= new Controller(view);
        view.setVisible(true);
    }

}
