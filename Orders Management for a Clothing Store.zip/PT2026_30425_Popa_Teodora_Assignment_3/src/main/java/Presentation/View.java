package Presentation;

import javax.swing.*;
import java.awt.*;

/**
 * View represents the main graphical window of the application and provides navigation buttons for accessing
 * the client, product and order management interfaces.
 * */

public class View extends JFrame
{
    private JButton clientsButton = new JButton("Clients INFO");
    private JButton productsButton = new JButton("Products INFO");
    private JButton ordersButton = new JButton("Orders INFO");

    /**
     * Creates the main applications window and initializes the navigation buttons for clients, products and orders.
     * */
    public View()
    {
        setTitle("Orders Management");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 80, 40, 80));

        panel.add(clientsButton);
        panel.add(productsButton);
        panel.add(ordersButton);

        add(panel);
    }

    /**
     * gets button for clients info/applications
     * */
    public JButton getClientsButton()
    {
        return clientsButton;
    }

    /**
     * gets button for products info/applications
     * */
    public JButton getProductsButton()
    {
     return productsButton;
    }

    /**
     * gets button for orders info/applications
     * */
    public JButton getOrdersButton() {
        return ordersButton;
    }
}
