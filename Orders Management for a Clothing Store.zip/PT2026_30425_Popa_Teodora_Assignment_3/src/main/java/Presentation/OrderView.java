package Presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * OrderView defines the GUI for order-related operations in the application.
 * It also contains the buttons and visual components for creating and viewing orders.
 * */

public class OrderView extends JFrame
{
    private JButton create = new JButton("PLACE Order");
    private JButton view = new JButton("VIEW Order");

    /**
     * Creates main view of order applications and adds their buttons.
     * */
        public OrderView(View mainView)
        {
            setTitle("Orders INFO");
            setSize(400, 250);
            setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e)
                {
                    mainView.setVisible(true);
                }
            });
            setLocationRelativeTo(null);

            JPanel panel= new JPanel(new GridLayout(1,2,10, 10));
            panel.setBorder(BorderFactory.createEmptyBorder(40,80,40,80));

            panel.add(create);
            panel.add(view);

            add(panel);
        }

    /**
     * gets button for create order
     * */
    public JButton getCreate() {
        return create;
    }

    /**
     * gets button for view orders
     * */
    public JButton getView() {
        return view;
    }


}
