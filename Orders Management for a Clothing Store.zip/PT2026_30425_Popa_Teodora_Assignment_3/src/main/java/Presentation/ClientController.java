package Presentation;

import BusinessLogic.ClientBLL;
import DataModel.Bill;
import DataModel.Client;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**ClientController connects the ClientView graphical interface with the business logic implemented in ClientBLL.
 * Also, it handles user actions: creating, viewing, updating and deleting clients and updates the GUI accordingly.*/
public class ClientController
{
    private ClientView clientView;
    private ClientBLL clientBLL;

/**
 * Creates a ClientController object and connects the buttons from ClientView with
 *  the corresponding client operations.
 *  */
    public ClientController(ClientView clientView)
    {
        this.clientView=clientView;
        this.clientBLL= new ClientBLL();

        clientView.getCreate().addActionListener(e->createClient());
        clientView.getView().addActionListener(e->viewClient());
        clientView.getUpdatde().addActionListener(e->updateClient());
        clientView.getDelete().addActionListener(e->deleteClient());

    }

    private void createClient()
    {
        JTextField nameField= new JTextField();
        JTextField emailField= new JTextField();

        JPanel panel= new JPanel(new GridLayout(2,2,10,10));
        panel.add(new JLabel("Name: "));
        panel.add(nameField);
        panel.add(new JLabel("Email: "));
        panel.add(emailField);

        int result=JOptionPane.showConfirmDialog(null,panel, "Create Client", JOptionPane.OK_CANCEL_OPTION);

        if(result==JOptionPane.OK_OPTION)
        {

            Client client= new Client(0, nameField.getText(), emailField.getText());
            clientBLL.addClient(client);
            JOptionPane.showMessageDialog(null, "Client added successfully!");
        }

      }

    private void viewClient()
    {
        List<Client> clients=clientBLL.viewAllClients();

        JTable table=TableReflection.createTable(clients);

       JOptionPane.showMessageDialog(null, new JScrollPane(table), "Clients", JOptionPane.INFORMATION_MESSAGE);
    }

    private Client chooseClient(String title)
    {
        List<Client> clients= clientBLL.viewAllClients();

        DefaultListModel<Client> model= new DefaultListModel<>();
        for(Client c: clients)
        {
            model.addElement(c);
        }

        JList<Client> list= new JList<>(model);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        int result= JOptionPane.showConfirmDialog(null, new JScrollPane(list), title, JOptionPane.OK_CANCEL_OPTION);

        if(result==JOptionPane.OK_OPTION)
            return list.getSelectedValue();

        return null;
    }

    private void updateClient()
    {
        Client selected =chooseClient("Choose client to update: ");
        if(selected==null) return;

        JTextField nameField=new JTextField(selected.getName());
        JTextField emailField= new JTextField(selected.getEmail());

        JPanel panel= new JPanel(new GridLayout(2,2,10,10));
        panel.add(new JLabel("Name: "));
        panel.add(nameField);
        panel.add(new JLabel("Email: "));
        panel.add(emailField);

        int result=JOptionPane.showConfirmDialog(null, panel, "Update Client", JOptionPane.OK_CANCEL_OPTION);

        if(result==JOptionPane.OK_OPTION)
        {
            Client updated= new Client(selected.getId(), nameField.getText(), emailField.getText());
            clientBLL.updateClient(updated);
            JOptionPane.showMessageDialog(null, "Client updated successfully!");
        }
    }

    private void deleteClient()
    {
       Client selected= chooseClient("Choose client to delete");
       if(selected==null)
           return;

       clientBLL.deleteClient(selected.getId());
       JOptionPane.showMessageDialog(null, "Client deleted successfully!");

    }

}
