package Presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**ClientView defines the GUI for client-related operations in the application.
 * It also contains the buttons and visual components for creating, viewing, updating and deleting clients.*/
public class ClientView extends JFrame
{
    private JButton create = new JButton("CREATE Client");
    private JButton view = new JButton("VIEW Clients");
    private JButton updatde = new JButton("UPDATE Client");
    private JButton delete= new JButton("DELETE Client");

    /**Creates main view of client applications and adds their buttons.*/
    public ClientView(View mainView)
    {
        setTitle("Clients INFO");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e)
            {
                mainView.setVisible(true);
            }
        });
        setLocationRelativeTo(null);

        JPanel panel= new JPanel(new GridLayout(2,2,10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(40,80,40,80));

        panel.add(create);
        panel.add(view);
        panel.add(updatde);
        panel.add(delete);


        add(panel);
    }

    /**gets button for create client*/
    public JButton getCreate() {
        return create;
    }

    /**gets button for view clients*/
    public JButton getView() {
        return view;
    }

    /**gets button for update client*/
    public JButton getUpdatde() {
        return updatde;
    }

    /**gets button for delete client*/
    public JButton getDelete() {
        return delete;
    }
}
