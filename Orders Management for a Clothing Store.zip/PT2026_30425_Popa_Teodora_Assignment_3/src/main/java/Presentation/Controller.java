package Presentation;

import DataModel.Client;

/**
 * Controller manages the navigation between the main application window and the specific client, product and
 * order views. Also, it connects the buttons from View to the corresponding controllers and GUI windows.
 * */

public class Controller
{
    private View mainView;

   /**
    * Creates a Controller object and connects the buttons from the main View
    * with the corresponding application windows and controllers.
    * */
    public Controller(View mainView)
    {
        this.mainView=mainView;

        mainView.getClientsButton().addActionListener(e->openClientView());
        mainView.getProductsButton().addActionListener(e->openProductView());
        mainView.getOrdersButton().addActionListener(e->openOrderView());
    }

    private void openClientView()
    {
        ClientView clientView= new ClientView(mainView);
        new ClientController(clientView);
        mainView.setVisible(true);
        clientView.setVisible(true);
    }

    private void openProductView()
    {
        ProductView productView= new ProductView(mainView);
        new ProductController(productView);
        mainView.setVisible(true);
        productView.setVisible(true);
    }

    private void openOrderView()
    {
        OrderView orderView= new OrderView(mainView);
        new OrderController(orderView);
        mainView.setVisible(true);
        orderView.setVisible(true);
    }

}
