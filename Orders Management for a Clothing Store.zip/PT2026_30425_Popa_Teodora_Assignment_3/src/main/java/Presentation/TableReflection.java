package Presentation;

import javax.swing.*;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Objects;

/**
 * TableReflection uses Java reflection to dynamically generate a JTable from a list of objects by automatically extracting
 * their fields as table columns and values.
 * */

public class TableReflection {

    /**
     * Dynamically generates a JTable from a list of objects
     * */
    public static JTable createTable(List<?> objects)
    {
        if(objects==null || objects.isEmpty())
            return new JTable();

        //uses reflection to get all fields (variables/attributes)
        // declared inside the class of the first object in the objects list.
        Field[] fields=objects.get(0).getClass().getDeclaredFields();

        String[] columns= new String[fields.length];
        Object[][] data= new Object[objects.size()][fields.length];

        for(int i=0; i< fields.length; i++)
            columns[i]=fields[i].getName();

        for(int i=0; i< objects.size(); i++)
        {
            for (int j = 0; j < fields.length; j++)
            {
               fields[j].setAccessible(true);
               try{
                   data[i][j]=fields[j].get(objects.get(i));
               }catch(IllegalAccessException e)
               {
                   e.printStackTrace();
               }
            }
        }

        return new JTable(data, columns);
    }

}
