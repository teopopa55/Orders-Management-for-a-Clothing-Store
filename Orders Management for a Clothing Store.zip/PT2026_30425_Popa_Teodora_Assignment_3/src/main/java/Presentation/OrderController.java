package Presentation;

import BusinessLogic.ClientBLL;
import BusinessLogic.OrderBLL;
import BusinessLogic.ProductBLL;
import DataAccess.BillDAO;
import DataModel.Bill;
import DataModel.Client;
import DataModel.Order;
import DataModel.Product;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * OrderController connects the OrderView graphical interface with the business logic implemented in OrderBLL.
 * Also, it handles user actions: creating and viewing orders and updates the GUI accordingly.
 * */

public class OrderController
{
    private OrderView orderView;
    private OrderBLL orderBLL;
    private ClientBLL clientBLL;
    private ProductBLL productBLL;
    private BillDAO billDAO= new BillDAO();

    /**
     * Creates an OrderController object and connects the buttons from OrderView with
     *  the corresponding order operations.
     *  */
    public OrderController(OrderView orderView)
    {
        this.orderView=orderView;
        this.orderBLL=new OrderBLL();
        this.clientBLL= new ClientBLL();
        this.productBLL= new ProductBLL();

        orderView.getCreate().addActionListener(e->placeOrder());
        orderView.getView().addActionListener(e->viewOrders());
    }

    private void placeOrder()
    {
      List<Client> clients= clientBLL.viewAllClients();
      List<Product> products= productBLL.viewAllProducts();

      JComboBox<Client> clientBox=new JComboBox<>(clients.toArray(new Client[0]));

      JPanel panel= new JPanel(new GridLayout(products.size()+ 1,3,10,10));

      panel.add(new JLabel("Client: "));
      panel.add(clientBox);
      panel.add(new JLabel(""));

        Map<Product, JTextField> quantityFields=new HashMap<>();

        for(Product product: products)
        {
            JCheckBox checkBox= new JCheckBox(product.toString());
            JTextField quantityField= new JTextField();

            panel.add(checkBox);
            panel.add(new JLabel("Quantity: "));
            panel.add(quantityField);

            quantityFields.put(product, quantityField);

            checkBox.addActionListener(e->quantityField.setEnabled(checkBox.isSelected()));
            quantityField.setEnabled(false);
        }

        int result= JOptionPane.showConfirmDialog(null, panel, "Place Order", JOptionPane.OK_CANCEL_OPTION);

        if(result==JOptionPane.OK_OPTION)
        {
            try{
            Client selectedClient=(Client) clientBox.getSelectedItem();

            Order order= new Order(0, selectedClient.getId());

            for(Map.Entry<Product, JTextField>entry: quantityFields.entrySet())
            {
                String text= entry.getValue().getText();

                if(!text.isEmpty() && entry.getValue().isEnabled())
                {
                    int quantity= Integer.parseInt(text);
                    if(quantity<=0)
                        throw new IllegalArgumentException("Quantity MUST BE GRATER THAN 0.");
                    order.getProducts().put(entry.getKey(), quantity);
                }
            }

                orderBLL.placeOrder(order);
                JOptionPane.showMessageDialog(null, "Order placed successfully!");

            }catch(IllegalArgumentException e)
            {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Stock Error!", JOptionPane.ERROR_MESSAGE);
            }

        }

    }

    private void viewOrders()
    {
        List<Bill> bills= billDAO.findAll();
        JTable table=TableReflection.createTable(bills);
        JOptionPane.showMessageDialog(null, new JScrollPane(table), "Orders History", JOptionPane.INFORMATION_MESSAGE);
    }
}
