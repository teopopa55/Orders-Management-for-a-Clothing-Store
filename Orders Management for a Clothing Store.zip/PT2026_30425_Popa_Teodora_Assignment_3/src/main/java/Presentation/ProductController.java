package Presentation;

import BusinessLogic.ProductBLL;
import DataModel.Client;
import DataModel.Product;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * ProductController connects the ProductView graphical interface with the business logic implemented in ProductBLL.
 * Also, it handles user actions: creating, viewing, updating and deleting products and updates the GUI accordingly.
 * */

public class ProductController
{
    private ProductView productView;
    private  ProductBLL productBLL;

    /**
     * Creates a ProductController object and connects the buttons from ProductView with
     *  the corresponding product operation.
     *  */

    public ProductController(ProductView productView)
    {
        this.productView=productView;
        this.productBLL=new ProductBLL();

        productView.getCreate().addActionListener(e->createProduct());
        productView.getView().addActionListener(e->viewProduct());
        productView.getUpdatde().addActionListener(e->updateProduct());
        productView.getDelete().addActionListener(e->deleteProduct());

    }

    private void createProduct()
    {
        JTextField nameField= new JTextField();
        JTextField priceField= new JTextField();
        JTextField quantityField= new JTextField();

        JPanel panel= new JPanel(new GridLayout(3,2,10,10));
        panel.add(new JLabel("Name: "));
        panel.add(nameField);
        panel.add(new JLabel("Price: "));
        panel.add(priceField);
        panel.add(new JLabel("Quantity: "));
        panel.add(quantityField);

        int result=JOptionPane.showConfirmDialog(null, panel, "Create Product", JOptionPane.OK_CANCEL_OPTION);

        if(result==JOptionPane.OK_OPTION)
        {
            Product product= new Product(0, nameField.getText(), Integer.parseInt(priceField.getText()), Integer.parseInt(quantityField.getText()));
            productBLL.addProduct(product);
            JOptionPane.showMessageDialog(null, "Product added successfully!");
        }

    }

    private void viewProduct()
    {
        List<Product> products=productBLL.viewAllProducts();

        JTable table = TableReflection.createTable(products);

        JOptionPane.showMessageDialog(null, new JScrollPane(table), "Products", JOptionPane.INFORMATION_MESSAGE);
    }

    private Product chooseProduct(String title)
    {
        List<Product> products= productBLL.viewAllProducts();

        DefaultListModel<Product> model= new DefaultListModel<>();
        for(Product p: products)
        {
            model.addElement(p);
        }

        JList<Product> list= new JList<>(model);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        int result= JOptionPane.showConfirmDialog(null, new JScrollPane(list), title, JOptionPane.OK_CANCEL_OPTION);

        if(result==JOptionPane.OK_OPTION)
            return list.getSelectedValue();

        return null;
    }

    private void updateProduct()
    {
       Product selected= chooseProduct("Choose product to update");

       if(selected==null) return;

       JTextField nameField= new JTextField(selected.getName());
       JTextField priceField= new JTextField(String.valueOf(selected.getPrice()));
       JTextField quantityField= new JTextField(String.valueOf(selected.getQuantity()));

       JPanel panel= new JPanel(new GridLayout(3,2,10,10));

       panel.add(new JLabel("Name:"));
       panel.add(nameField);
       panel.add(new JLabel("Price:"));
       panel.add(priceField);
       panel.add(new JLabel("Quantity:"));
       panel.add(quantityField);

       int result= JOptionPane.showConfirmDialog(null, panel, "Update Product", JOptionPane.OK_CANCEL_OPTION);

       if(result==JOptionPane.OK_OPTION)
       {
           Product updated=new Product(selected.getId(), nameField.getText(), Integer.parseInt(priceField.getText()), Integer.parseInt(quantityField.getText()));
           productBLL.updateProduct(updated);

           JOptionPane.showMessageDialog(null, "Product updated successfully!");
       }

    }

    private void deleteProduct()
    {
       Product selected= chooseProduct("Choose product to delete");

       if(selected==null) return;

       productBLL.deleteProduct(selected.getId());

       JOptionPane.showMessageDialog(null, "Product deleted successfully!");

    }
}
