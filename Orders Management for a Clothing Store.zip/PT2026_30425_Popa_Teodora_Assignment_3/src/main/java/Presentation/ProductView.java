package Presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**ProductView defines the GUI for product-related operations in the application. It also contains the buttons and visual
 * components for creating, viewing, updating and deleting products.
 * */
public class ProductView extends JFrame
{
    private JButton create = new JButton("CREATE Product");
    private JButton view = new JButton("VIEW Products");
    private JButton updatde = new JButton("UPDATE Product");
    private JButton delete= new JButton("DELETE Product");

    /**
     * Creates main view of product applications and adds their buttons.
     * */
    public ProductView(View mainView)
    {
        setTitle("Products INFO");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e)
            {
                mainView.setVisible(true);
            }
        });
        setLocationRelativeTo(null);

        JPanel panel= new JPanel(new GridLayout(2,2,10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(40,80,40,80));

        panel.add(create);
        panel.add(view);
        panel.add(updatde);
        panel.add(delete);


        add(panel);
    }

    /**
     * gets button for create product
     * */
    public JButton getCreate() {
        return create;
    }

    /**
     * gets button for view products
     * */
    public JButton getView() {
        return view;
    }

    /**
     * gets button for update product
     * */
    public JButton getUpdatde() {
        return updatde;
    }

    /**
     * gets button for delete product
     * */
    public JButton getDelete() {
        return delete;
    }

}
