package DataModel;

/**
 * This defines an immutable Bill data model for storing history records.
 * In the database this would represent the table log which preserves immutable order history.
 * */
public record Bill (int id, int orderId, String clientName, String productName, int quantity, int price, int total)
{
   //immutable class => data cannot be changed after the object is created
    //usefull for kepping permanent and reliable order history
    //record bc they are a concise way to create immutable data-holder classes
}

