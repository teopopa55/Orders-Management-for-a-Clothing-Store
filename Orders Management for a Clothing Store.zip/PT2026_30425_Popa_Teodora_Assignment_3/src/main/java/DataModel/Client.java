package DataModel;

/**
 * The Client class helps keeping track of all people purchasing products.
 * Each one of them, just like in table clients from the database, has an id, name and email,
 * which must contain @ symbol.
 * */
public class Client {

    private int id;
    private String name;
    private String email;

    /**
     *  Constructs Client with all attributes defined
     *  */
    public Client(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }


    /**
     * reflection uses newInstance() which requires no-argument constructor
     * */
    public Client()
    {

    }

    /**
     * Function to print Client's details
     * */
    @Override
    public String toString()
    {
        return name + " (" + email +")";
    }

    /**
     * Function to get Client's id
     * */
    public int getId() {
        return id;
    }

    /**
     * Function to set Client's id
     * */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Function to get Client's name
     * */
    public String getName() {
        return name;
    }

    /**
     * Function to set Client's name
     * */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Function to get Client's email
     * */
    public String getEmail() {
        return email;
    }

    /**
     * Function to set Client's email
     * */
    public void setEmail(String email) {
        this.email = email;
    }
}
