package DataModel;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

/**
 * The Order class helps managing the placed orders. Each one, just like in the databse,
 * must contain an id, a client id, and a map where we store the desired products and their quantity.
 * */

public class Order {

    private int id;
    private int clientId;
    private Map<Product, Integer> products=new HashMap<>();

    /**
     *  Constructs Order with all attributes defined
     *  */
    public Order(int id, int clientId) {
        this.id = id;
        this.clientId = clientId;
    }

    private int calculatePrice()
    {
                     // gets all pars product-quantity
        return products.entrySet()
                //turns the pairs into a stream
                .stream()
                //key-> product, value->quantity, computes the price for that part of the order
                .mapToInt(entry->entry.getKey().getPrice()*entry.getValue())
               //sums them all
                .sum();

    }

    /**
     * Function to get Order's id
     * */
    public int getId() {
        return id;
    }

    /**
     * Function to set Order's id
     * */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Function to get Order's client's id
     * */
    public int getClientId() {
        return clientId;
    }

    /**
     * Function to set Order's client's id
     * */
    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    /**
     * Function to get Order's list of products
     * */
    public Map<Product, Integer> getProducts() {
        return products;
    }

    /**
     * Function to set Order's list of products
     * */
    public void setProducts(Map<Product, Integer> products) {
        this.products = products;
    }
}
