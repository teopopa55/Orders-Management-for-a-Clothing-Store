package DataModel;

/**
 * The Product class helps modelling a product entity from the database by storing its
 * id, name, price and stock quantity.
 * */
public class Product {

    private int id;
    private String name;
    private int price;
    private int quantity;

    /**
     * Constructs Product with all attributes defined
     * */
    public Product(int id, String name, int price, int quantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    //reflection uses newInstance() which requires no-argument constructor
    /**
     * reflection uses newInstance() which requires no-argument constructor
     * */
    public Product()
    {

    }

    /**
     * Function to print Product's details
     * */
    @Override
    public String toString()
    {
    return name + " | price:"+price+" | stock: "+quantity;
    }

    /**
     * Function to get Product's id
     * */
    public int getId() {
        return id;
    }

    /**
     * Function to set Product's id
     * */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Function to get Product's name
     * */
    public String getName() {
        return name;
    }

    /**
     * Function to set Product's name
     * */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Function to get the price
     * */
    public int getPrice() {
        return price;
    }

    /**
     * Function to set the price
     * */
    public void setPrice(int price) {
        this.price = price;
    }

    /**
     * Function to get the quantity
     * */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Function to set the quantity
     * */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
